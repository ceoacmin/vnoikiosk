const express = require('express');
const router = express.Router();
const db = require('../config/db');
const socketManager = require('../sockets/socketManager');

router.post('/verify', async (req, res) => {
    try {
        const username = (req.body.username || req.body.Username || req.body.userName || '').toString().trim();
        const accessKey = (req.body.access_key || req.body.AccessKey || req.body.accessKey || '').toString().trim();
        const machineId = (req.body.machine_id || req.body.MachineId || req.body.machineId || '').toString().trim();
        const ip = (req.body.ip_address || req.body.IpAddress || req.body.ipAddress || '').toString().trim();

        const { rows: adminKeys } = await db.query("SELECT admin_id FROM admin_access_keys WHERE key_code = $1", [accessKey]);
        let adminId = null;
        let exams = [];

        if (adminKeys.length > 0) {
            adminId = adminKeys[0].admin_id;
            const { rows } = await db.query("SELECT title, contest_link, access_code FROM exams WHERE admin_id = $1 AND is_active = true", [adminId]);
            exams = rows;
        } else {
            const { rows } = await db.query("SELECT title, contest_link, access_code, admin_id FROM exams WHERE access_code = $1 AND is_active = true", [accessKey]);
            exams = rows;
            if (rows.length > 0) adminId = rows[0].admin_id;
        }

        if (adminId !== null) {
            await db.query(`
                INSERT INTO students (username, admin_id, ip_address, machine_id, status, last_ping) 
                VALUES ($1, $2, $3, $4, 'ONLINE', NOW()) 
                ON CONFLICT (username) DO UPDATE 
                SET ip_address = EXCLUDED.ip_address, machine_id = EXCLUDED.machine_id, status = 'ONLINE', last_ping = NOW()
            `, [username, adminId, ip, machineId]);
            socketManager.getIO().emit('data_updated');
            res.json({ success: true, exams });
        } else {
            console.log(`[KIOSK VERIFY] Rejected: Key ${accessKey}`);
            res.json({ success: false, error: 'Mã Access Key không tồn tại hoặc đã đóng.' });
        }
    } catch (e) {
        console.error('[KIOSK VERIFY ERROR]', e.message);
        res.json({ success: false, error: e.message });
    }
});

router.post('/ping', async (req, res) => {
    try {
        const machineId = (req.body.machine_id || req.body.MachineId || req.body.machineId || '').toString().trim();
        const status = (req.body.status || req.body.Status || 'ONLINE').toString().trim();
        await db.query("UPDATE students SET status=$1, last_ping=NOW() WHERE machine_id=$2", [status, machineId]);
        socketManager.getIO().emit('data_updated');
        res.json({ success: true });
    } catch (e) {
        console.error('[PING ERROR]', e.message);
        res.json({ success: false });
    }
});

router.post('/exit_success', async (req, res) => {
    try {
        const username = (req.body.username || req.body.Username || req.body.userName || '').toString().trim();
        await db.query("UPDATE students SET status='ĐÃ NỘP BÀI', last_ping=NOW() WHERE username=$1", [username]);
        socketManager.getIO().emit('data_updated');
        res.json({ success: true });
    } catch (e) {
        console.error('[EXIT SUCCESS ERROR]', e.message);
        res.json({ success: false });
    }
});

router.post('/crash_report', async (req, res) => {
    try {
        const username = (req.body.username || req.body.Username || req.body.userName || '').toString().trim();
        await db.query("UPDATE students SET status='CRASHED' WHERE username=$1", [username]);
        socketManager.getIO().emit('data_updated');
        res.json({ success: true });
    } catch (e) {
        console.error('[CRASH REPORT ERROR]', e.message);
        res.json({ success: false });
    }
});

module.exports = router;