let prevStats = { students: 0, exams: 0 };
const socket = typeof io !== 'undefined' ? io() : null;

function switchView(viewName) {
    document.querySelectorAll('.view-section').forEach(el => el.classList.add('hidden'));
    const target = document.getElementById('view-' + viewName);
    if(target) target.classList.remove('hidden');
    
    document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('nav-active'));
    const nav = document.getElementById('nav-' + viewName);
    if(nav) nav.classList.add('nav-active');
    
    const titles = { 'overview': 'BẢNG THỐNG KÊ TỔNG QUAN', 'access': 'MÃ TRUY CẬP PHÒNG THI', 'addexam': 'TẠO BÀI THI MỚI', 'exams': 'QUẢN LÝ BÀI THI', 'students': 'GIÁM SÁT HỌC SINH', 'settings': 'CÀI ĐẶT BẢO MẬT' };
    const titleEl = document.getElementById('page-title');
    if(titleEl) {
        titleEl.style.opacity = 0;
        titleEl.style.transform = 'translateY(-5px)';
        setTimeout(() => {
            titleEl.innerText = titles[viewName] || 'WORKSPACE';
            titleEl.style.opacity = 1;
            titleEl.style.transform = 'translateY(0)';
        }, 150);
    }
    if(viewName !== 'settings' && viewName !== 'addexam') loadData();
}

async function loadData() {
    try {
        const res = await apiFetch('/api/admin/data');
        if (!res) return;
        if (res.success) {
            const adminInfo = res.admin || {};
            const examsList = res.exams || [];
            const studentsList = res.students || [];
            const mKey = res.master_key || 'CHƯA TẠO';

            const statSt = document.getElementById('stat-students');
            const statEx = document.getElementById('stat-exams');
            if(statSt) animateValue(statSt, prevStats.students, studentsList.length, 800);
            if(statEx) animateValue(statEx, prevStats.exams, examsList.length, 800);
            prevStats = { students: studentsList.length, exams: examsList.length };
            
            const adminNameEl = document.getElementById('admin-name');
            if(adminNameEl && adminInfo.username) adminNameEl.innerText = adminInfo.username;
            
            const initial = document.getElementById('avatar-initial');
            const logoImg = document.getElementById('sidebar-logo-img');
            if(initial && logoImg && adminInfo.username) {
                if(adminInfo.avatar_url && adminInfo.avatar_url !== 'default' && adminInfo.avatar_url !== 'default.png') {
                    initial.classList.add('hidden');
                    logoImg.src = '/uploads/' + adminInfo.avatar_url;
                    logoImg.classList.remove('hidden');
                } else {
                    initial.innerText = adminInfo.username.charAt(0).toUpperCase();
                    initial.classList.remove('hidden');
                    logoImg.classList.add('hidden');
                }
            }
            
            const dashKey = document.getElementById('dash-access-key');
            const admKey = document.getElementById('admin-access-key');
            if(dashKey) dashKey.innerText = mKey;
            if(admKey) admKey.innerText = mKey;

            const tbodyExam = document.getElementById('exam-list');
            if(tbodyExam) {
                tbodyExam.innerHTML = '';
                if(examsList.length === 0) {
                    tbodyExam.innerHTML = `<tr><td colspan="4" class="text-center text-slate-500 py-10 font-bold text-[10px] tracking-widest uppercase">Trống</td></tr>`;
                } else {
                    examsList.forEach(e => {
                        tbodyExam.innerHTML += `
                            <tr>
                                <td class="font-bold text-sky-400 pl-6">${e.title}</td>
                                <td class="text-center"><button onclick="showLinkModal('${e.contest_link}')" class="btn-outline !py-1.5 !px-3 !text-[9px] !bg-blue-500/10 !text-blue-400 !border-blue-500/30 mx-auto">XEM</button></td>
                                <td class="text-center"><button onclick="showCodeModal('${e.access_code}')" class="btn-outline !py-1.5 !px-3 !text-[9px] !bg-emerald-500/10 !text-emerald-400 !border-emerald-500/30 mx-auto">MÃ LẺ</button></td>
                                <td class="text-right pr-6"><button onclick="deleteExam(${e.id})" class="px-3 py-1.5 rounded-lg text-[9px] font-black bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white transition uppercase">XÓA</button></td>
                            </tr>
                        `;
                    });
                }
            }

            const tbodyStudent = document.getElementById('student-list');
            if(tbodyStudent) {
                tbodyStudent.innerHTML = '';
                if(studentsList.length === 0) {
                    tbodyStudent.innerHTML = `<tr><td colspan="5" class="text-center text-slate-500 py-10 font-bold text-[10px] tracking-widest uppercase">Trống</td></tr>`;
                } else {
                    const now = Date.now();
                    studentsList.forEach(s => {
                        const pingTime = s.ping_ms || new Date(s.last_ping || s.last_time).getTime();
                        const isOnline = (now - pingTime) <= 20000;
                        let stText = 'OFFLINE'; let stColor = 'text-slate-500 bg-slate-800/50 border-slate-700';
                        if(isOnline && s.status !== 'CRASHED' && s.status !== 'ĐÃ NỘP BÀI' && s.status !== 'COMPLETED') { stText = 'ONLINE LIVE'; stColor = 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30'; }
                        else if (s.status === 'CRASHED' || s.status === 'CRASH') { stText = 'CRASHED'; stColor = 'text-red-400 bg-red-500/10 border-red-500/30'; }
                        else if (s.status === 'ĐÃ NỘP BÀI' || s.status === 'COMPLETED') { stText = 'ĐÃ NỘP'; stColor = 'text-sky-400 bg-sky-500/10 border-sky-500/30'; }
                        const timeStr = s.last_time || new Date(pingTime).toLocaleTimeString('vi-VN');
                        tbodyStudent.innerHTML += `
                            <tr>
                                <td class="font-bold text-sky-400 pl-6">${s.username}</td>
                                <td class="text-center font-mono text-[9px] text-slate-400">${s.ip_address}</td>
                                <td class="text-center font-mono text-[9px] text-slate-500 truncate max-w-[100px] mx-auto" title="${s.machine_id}">${s.machine_id}</td>
                                <td class="text-center text-slate-400 text-[10px] font-bold">${timeStr}</td>
                                <td class="text-right pr-6"><span class="font-black text-[9px] px-2.5 py-1 rounded-lg border inline-flex items-center tracking-widest ${stColor}">${stText}</span></td>
                            </tr>
                        `;
                    });
                }
            }
        }
    } catch(e) { }
}

if(socket) {
    socket.on('data_updated', loadData);
    socket.on('connected', loadData);
}
if(document.getElementById('view-overview')) {
    switchView('overview');
}