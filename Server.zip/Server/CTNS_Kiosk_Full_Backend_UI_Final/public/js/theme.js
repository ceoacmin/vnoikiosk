setInterval(() => {
    const timeEl = document.getElementById('current-time');
    if (timeEl) timeEl.innerText = new Date().toLocaleTimeString('vi-VN');
}, 1000);